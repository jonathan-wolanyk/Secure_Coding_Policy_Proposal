// Jonathan Wolanyk
// Professor Prasad
// CS-405: Secure Coding
// March 26, 2023

#include <iostream>

bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception

    std::cout << "Running even more custom application logic... " << std::endl;

    // create a smart point to hold our collection
    int* list = new int[2];

    int result = list[3];

    // Throws error
    throw std::runtime_error("Error has been thrown by do_even_more_custom_application_logic()");

    return true;
}
void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    try {
        // wraps do_even_more_custom_application_logic() in an if statement
        if (do_even_more_custom_application_logic())
        {
            // Outputs following statement if successful
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }

        // TODO: Throw a custom exception derived from std::exception
        //  and catch it explicitly in main
        throw std::runtime_error("Runtime error thrown from do_custom_application_logic()");

        std::cout << "Leaving Custom Application Logic." << std::endl;
    }

    // Catch statement if try fails
    catch (const std::exception& e) {
        std::cerr << "Caught the following exception: " << e.what() << std::endl;
    }
}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception

    // If the denominator is 0
    if (den == 0.0f)
    {
        // Throw the divide by zero exception
        throw std::runtime_error("Runtime error: cannot divide by 0");
    }
    return (num / den);
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.

    // Try the given code
    try {
        float numerator = 10.0f;
        float denominator = 0;

        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;

    }

    // Catch if given code fails
    catch (const std::exception& e) {
        std::cerr << "Caught the following exception while trying to divide: " << e.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception 
    //  that wraps the whole main function, and displays a message to the console.

    // Try block to wrap main functions
    try {
        do_division();
        do_custom_application_logic();
    }

    // catch block for custom exception
    catch (const std::runtime_error& e) {
        std::cerr << "Caught my custom exception: " << e.what() << std::endl;
    }

    // catch block for std::exception
    catch (const std::exception& e) {
        std::cerr << "Caught std::exception: " << e.what() << std::endl;
    }

    // catch block for uncaught exceptions
    catch (...) {
        std::cerr << "Caught uncaught exception" << std::endl;
    }

    std::cout << "Exiting main()" << std::endl;

    return 0;
}
